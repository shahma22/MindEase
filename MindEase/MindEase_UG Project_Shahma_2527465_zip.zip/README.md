# MindEase — AI-Powered Mental Health Wellness Website
### SEC6201 Undergraduate Project | BEng (Hons) Software Engineering
**Student:** Shahma Mohammed Salih | **Student Number:** 2527465

---

## What is MindEase?

MindEase is a free, anonymous, AI-powered mental wellness web application
designed specifically for university students. It uses TextBlob sentiment
analysis and fuzzy logic to provide emotional support through an interactive
AI chatbot, mood tracking, journaling, analytics, and guided breathing exercises.

---

## Project Structure

```
MindEase/
├── app.py                  ← Main Flask application (all routes and AI logic)
├── mindease.db             ← SQLite database (auto-created on first run)
├── README.md               ← This file
├── requirements.txt        ← Python dependencies
├── mindease_database_export.sql  ← SQL schema and sample data export
├── static/
│   └── css/
│       └── style.css       ← Full stylesheet including dark mode
└── templates/
    ├── base.html           ← Shared navigation, footer, dark mode toggle
    ├── home.html           ← Landing page
    ├── chat.html           ← AI chatbot with fuzzy logic display
    ├── wellness.html       ← Single wellness sentiment check
    ├── mood.html           ← Mood tracker with personalised quotes
    ├── journal.html        ← Journal entries
    ├── analytics.html      ← Mood analytics charts dashboard
    ├── breathing.html      ← Animated breathing exercise
    ├── resources.html      ← Tips and UAE crisis contacts
    └── about.html          ← Project information and ethics
```

---

## Requirements

- Python 3.8 or above
- pip (Python package installer)
- A modern web browser (Google Chrome recommended)
- Internet connection (for Google Fonts and Chart.js CDN)

---

## Setup Instructions

### Step 1 — Download and Extract the Project

Download the project ZIP file and extract it to a folder on your computer.
Open the extracted folder — you should see app.py and the other files listed above.

---

### Step 2 — Open Terminal or Command Prompt

**Windows:**
- Press Windows + R, type cmd, press Enter
- Navigate to your project folder:
```
cd C:\Users\YourName\MindEase
```

**Mac / Linux:**
- Open Terminal
- Navigate to your project folder:
```
cd /path/to/MindEase
```

---

### Step 3 — Install Python Dependencies

Run this command to install Flask and TextBlob:

```
pip install flask textblob
```

Then download the language data TextBlob needs:

```
python -m textblob.download_corpora
```

If pip is not recognised, try:

```
pip3 install flask textblob
python3 -m textblob.download_corpora
```

---

### Step 4 — Run the Application

```
python app.py
```

Or on Mac/Linux:

```
python3 app.py
```

You should see this output in your terminal:

```
 * Running on http://127.0.0.1:5000
 * Debug mode: on
```

---

### Step 5 — Open in Browser

Open Google Chrome and go to:

```
http://127.0.0.1:5000
```

MindEase is now running on your computer.

---

## How to Stop the Application

Go back to your terminal and press:

```
Ctrl + C
```

---

## Database Information

MindEase uses SQLite — a lightweight file-based database.

- The database file is called **mindease.db**
- It is created **automatically** when you run app.py for the first time
- You do NOT need to install MySQL, PostgreSQL, or XAMPP
- No database server is required
- The file stores two tables: **moods** and **journal**

### Viewing the Database (Optional)

If you want to see the database contents visually, download the free tool:
**DB Browser for SQLite** from https://sqlitebrowser.org
Then open the mindease.db file with it.

### SQL Export

The file **mindease_database_export.sql** contains:
- The full database schema (CREATE TABLE statements)
- Sample data (INSERT statements)

To import this into a fresh SQLite database manually:
```
sqlite3 mindease.db < mindease_database_export.sql
```

---

## Features

| Feature | URL | Description |
|---------|-----|-------------|
| Home Page | / | Landing page with feature overview |
| AI Chat | /chat | Interactive chatbot with fuzzy logic |
| Wellness Check | /wellness | Single sentiment analysis |
| Mood Tracker | /mood | Log and track daily moods |
| Journal | /journal | Private journal entries |
| Analytics | /analytics | Mood charts and statistics |
| Breathing | /breathing | Guided breathing exercise |
| Resources | /resources | Wellness tips and UAE crisis contacts |
| About | /about | Project information |

---

## AI Features Explained

### Sentiment Analysis
Uses TextBlob to calculate a polarity score from -1.0 (very negative) to +1.0 (very positive).

### Fuzzy Logic Classification
Maps the polarity score to five emotional levels:
- Very Positive: +0.5 to +1.0
- Positive: +0.1 to +0.5
- Neutral: -0.1 to +0.1
- Negative: -0.4 to -0.1
- Very Negative: -1.0 to -0.4

### Keyword Detection
Detects 8 topic categories: exam, sleep, lonely, family, anxiety, money, work, overwhelmed.
Topic-specific responses are triggered when keywords are detected.

### Crisis Detection
After 2 consecutive Very Negative messages, UAE crisis contacts appear automatically.

---

## UAE Crisis Contacts (built into the platform)

- **800-HOPE (4673)** — National Mental Health Helpline, free, 24/7
- **Emirates Health Services:** 800-EHS (347)
- **Dubai Health Authority:** 800-342

---

## Technology Stack

| Technology | Version | Purpose |
|-----------|---------|---------|
| Python | 3.8+ | Backend language |
| Flask | 3.0.x | Web framework |
| TextBlob | 0.18.x | Sentiment analysis |
| SQLite3 | Built-in | Database |
| HTML5 | — | Frontend structure |
| CSS3 | — | Styling and dark mode |
| JavaScript | ES6+ | Chat, animation, charts |
| Chart.js | CDN | Analytics charts |
| Google Fonts | CDN | Poppins typography |

---

## Troubleshooting

**Problem:** `ModuleNotFoundError: No module named 'flask'`
**Solution:** Run `pip install flask textblob` again

**Problem:** Browser shows "This site can't be reached"
**Solution:** Make sure `python app.py` is still running in the terminal

**Problem:** `python` is not recognised
**Solution:** Try `python3 app.py` instead

**Problem:** TextBlob gives an error about missing data
**Solution:** Run `python -m textblob.download_corpora`

**Problem:** Port 5000 already in use
**Solution:** Stop any other Flask apps running, or change the port in app.py:
```python
app.run(debug=True, port=5001)
```
Then visit http://127.0.0.1:5001 instead

---

## Ethical Statement

MindEase is not a substitute for professional mental health support.
It is designed as an early support tool to complement, not replace, professional care.
No personal data is collected. All usage is anonymous.
Crisis support contacts are displayed on every page.

---

## Academic Information

- **Module:** SEC6201 Undergraduate Project
- **Programme:** BEng (Hons) Software Engineering
- **Student:** Shahma Mohammed Salih
- **Student Number:** 2527465
- **Academic Year:** 2025/2026
